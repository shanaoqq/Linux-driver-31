#include <linux/init.h>
#include <linux/module.h>

//入口
//__init 将入口函数放到 .init.text段中
static int __init demo_init(void)
{
	return 0;
}
module_init(demo_init);
	//module_init内核中的一个宏
	//将函数的名字告诉给内核，以共内核回调

//出口
//__exit 将出口放到.exit.text段中
static void  __exit demo_exit(void)
{

}
module_exit(demo_exit);
	//module_exit内核中的一个宏
	//将函数的名字告诉给内核，以共内核回调

//许可证
MODULE_LICENSE("GPL");//遵从开源协议
